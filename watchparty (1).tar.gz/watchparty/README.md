# Watch Party — Rust scaffold (Phase 1)

A synchronized home-video watch party. Upload MP4s you own, watch them together
in the browser, with playback controls that stay in sync and a video call
alongside. Backend is Rust (Axum); frontend is Rust compiled to WASM (Leptos).
No SFU — with ≤4 people the video call is a plain WebRTC mesh.

**This scaffold covers Phases 1–2:** upload/list/play home videos, AND keep
playback in sync across everyone in a room — pause/play/seek/skip and load
video all propagate to every viewer, with a heartbeat that re-aligns drift.
WebRTC video calls (Phase 3) are next; the `shared::Signal` messages and relay
are already wired.

## What's verified

The `shared` and `server` crates compile and were tested end-to-end:
- upload → list → range/seek (`GET /media/<id>.mp4` → `206 Partial Content`);
- sync over `/ws` with two live clients — join, play, seek, pause, load-video,
  peer join/leave, and the heartbeat re-broadcast all propagate correctly.

The `web` crate is written against Leptos 0.6 and builds with `trunk` on a recent
stable Rust toolchain (edition-2024 dependencies mean you'll want Rust ≥ 1.85).

## Layout

```
watchparty/
├─ Cargo.toml            workspace (builds shared + server natively)
├─ rust-toolchain.toml   stable + wasm32 target
├─ shared/               protocol types shared by server AND frontend
│  └─ src/lib.rs         Video, ClientMsg, ServerMsg, ...
├─ server/               Axum backend
│  └─ src/
│     ├─ main.rs         router + app state
│     ├─ media.rs        upload + range serving + JSON library
│     ├─ ws.rs           WebSocket: parse ClientMsg, drive room, stream ServerMsg
│     └─ rooms.rs        rooms: authoritative playback state + fan-out
└─ web/                  Leptos frontend → WASM
   ├─ index.html         trunk entry + styles
   ├─ Trunk.toml         dev proxy to the backend
   └─ src/
      ├─ main.rs         mount
      ├─ app.rs          UI: join room, synced player, peers, library
      └─ api.rs          fetch helpers
```

## Prerequisites

```bash
# Rust (recent stable), then:
rustup target add wasm32-unknown-unknown
cargo install trunk
```

## Run it (development)

Two terminals from the repo root:

```bash
# 1) backend on :3000
cargo run -p server

# 2) frontend on :8080 (proxies /api, /media, /ws to :3000)
cd web && trunk serve
```

Open http://localhost:8080 in two browser windows. Enter the same room code in
both and click Join, pick a video from the library, and press play in one — the
other follows. Pause, seek, and switching videos all stay in sync. Uploaded
files land in `./media/` with a `videos.json` index.

## Run it (production, single binary + static assets)

```bash
cd web && trunk build --release      # outputs web/dist
cd .. && cargo run -p server --release
# Axum serves the built frontend AND the API/media on http://localhost:3000
```

## Endpoints

| Method | Path              | Purpose                                   |
|--------|-------------------|-------------------------------------------|
| GET    | `/api/videos`     | JSON list of uploaded videos              |
| POST   | `/api/upload`     | raw MP4 body + `x-filename` header        |
| GET    | `/media/<id>.mp4` | video stream, supports Range (seek)       |
| GET    | `/ws`             | WebSocket: room join + playback sync      |

## Next phases

- **Phase 2 — sync. (done)** Room actors hold authoritative playback state; any
  `Play/Pause/Seek/LoadVideo` restamps it with the server clock and broadcasts
  `ServerMsg::State`. Clients hard-correct when drift > 0.3s; a 3s heartbeat
  re-aligns anyone who fell behind. (A gentle ±5% playbackRate nudge instead of
  a hard seek is an easy refinement in `apply_state`.)
- **Phase 3 — calls.** WebRTC mesh (≤4 peers). Relay SDP/ICE via the existing
  `/ws` using `ClientMsg::Signal` / `ServerMsg::Signal`. Add public STUN, then a
  self-hosted `coturn` for NAT fallback.
- **Phase 4 — polish.** Room codes/invite links, presence list, reconnect,
  `ffmpeg -movflags +faststart` on upload, swap the JSON index for SQLite
  (`sqlx`), deploy on one small VPS running the server + coturn.

## Notes

- Dependency versions are pinned conservatively; bump to Axum 0.8 / Leptos 0.7
  whenever you like.
- Uploads stream to disk with a 4 GiB cap (`MAX_UPLOAD` in `server/src/media.rs`).
- Set `MEDIA_DIR` to change where videos are stored (default `./media`).
