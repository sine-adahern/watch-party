//! Phase 2 frontend: join a room, then keep a shared `<video>` in sync over the
//! WebSocket. User play/pause/seek is sent up; incoming `State` is applied back
//! down. A short "suppress" window stops programmatic changes from echoing.
//!
//! NOTE: the server sync path is verified end-to-end; this WASM module is
//! written against Leptos 0.6 and compiles with `trunk` on your toolchain.

use leptos::html::Video;
use leptos::*;
use wasm_bindgen::prelude::*;
use wasm_bindgen::JsCast;
use web_sys::{HtmlInputElement, MessageEvent, WebSocket};

use shared::{ClientMsg, Peer, ServerMsg, Video as VideoMeta};

use crate::api;

fn now_ms() -> f64 {
    js_sys::Date::now()
}

/// Serialize a `ClientMsg` and send it, if the socket is open.
fn send(ws: &WebSocket, msg: &ClientMsg) {
    if let Ok(json) = serde_json::to_string(msg) {
        let _ = ws.send_with_str(&json);
    }
}

#[component]
pub fn App() -> impl IntoView {
    let videos = create_rw_signal(Vec::<VideoMeta>::new());
    let current = create_rw_signal(None::<VideoMeta>);
    let status = create_rw_signal(String::new());
    let peers = create_rw_signal(Vec::<Peer>::new());
    let me = create_rw_signal(None::<String>);
    let joined = create_rw_signal(false);
    let room_input = create_rw_signal("main".to_string());
    let name_input = create_rw_signal(String::new());
    // Programmatic video changes set this a bit in the future; user-event
    // handlers ignore events until then so we don't echo our own updates.
    let suppress_until = create_rw_signal(0.0_f64);
    let ws_sig = create_rw_signal(None::<WebSocket>);
    let video_ref = create_node_ref::<Video>();

    // Load the library once.
    spawn_local(async move {
        match api::fetch_videos().await {
            Ok(v) => videos.set(v),
            Err(e) => status.set(format!("Could not load library: {e}")),
        }
    });

    // ---- Apply an incoming authoritative State to the local <video> ----
    let apply_state =
        move |playing: bool, position: f64, video_id: Option<String>| {
            // Switch source if the room is on a different video.
            if let Some(vid) = &video_id {
                let need = current.get_untracked().map(|c| &c.id != vid).unwrap_or(true);
                if need {
                    if let Some(v) = videos.get_untracked().into_iter().find(|v| &v.id == vid) {
                        current.set(Some(v));
                    }
                }
            }
            suppress_until.set(now_ms() + 700.0);
            if let Some(el) = video_ref.get_untracked() {
                if playing {
                    let drift = el.current_time() - position;
                    if drift.abs() > 0.3 {
                        el.set_current_time(position);
                    }
                    let _ = el.play();
                } else {
                    let _ = el.pause();
                    el.set_current_time(position);
                }
            }
        };

    // ---- Join: open the socket and wire message handling ----
    let do_join = move |_| {
        if joined.get_untracked() {
            return;
        }
        let room = room_input.get_untracked();
        let name = {
            let n = name_input.get_untracked();
            if n.trim().is_empty() { "guest".to_string() } else { n }
        };

        let loc = web_sys::window().unwrap().location();
        let scheme = if loc.protocol().unwrap_or_default() == "https:" { "wss" } else { "ws" };
        let host = loc.host().unwrap_or_default();
        let url = format!("{scheme}://{host}/ws");

        let ws = match WebSocket::new(&url) {
            Ok(w) => w,
            Err(_) => {
                status.set("Could not open WebSocket".into());
                return;
            }
        };

        // onopen -> send Join
        {
            let ws2 = ws.clone();
            let room2 = room.clone();
            let name2 = name.clone();
            let vid = current.get_untracked().map(|v| v.id);
            let onopen = Closure::<dyn FnMut()>::new(move || {
                send(&ws2, &ClientMsg::Join {
                    room: room2.clone(),
                    name: name2.clone(),
                    video_id: vid.clone(),
                });
            });
            ws.set_onopen(Some(onopen.as_ref().unchecked_ref()));
            onopen.forget();
        }

        // onmessage -> route ServerMsg
        {
            let onmessage = Closure::<dyn FnMut(MessageEvent)>::new(move |e: MessageEvent| {
                let Some(txt) = e.data().as_string() else { return };
                let Ok(msg) = serde_json::from_str::<ServerMsg>(&txt) else { return };
                match msg {
                    ServerMsg::Welcome { you, peers: list } => {
                        me.set(Some(you));
                        peers.set(list);
                    }
                    ServerMsg::PeerJoined { peer } => peers.update(|ps| {
                        if !ps.iter().any(|p| p.id == peer.id) {
                            ps.push(peer);
                        }
                    }),
                    ServerMsg::PeerLeft { id } => {
                        peers.update(|ps| ps.retain(|p| p.id != id))
                    }
                    ServerMsg::State { playing, position, video_id, .. } => {
                        apply_state(playing, position, video_id);
                    }
                    ServerMsg::Signal { .. } => { /* Phase 3 */ }
                }
            });
            ws.set_onmessage(Some(onmessage.as_ref().unchecked_ref()));
            onmessage.forget();
        }

        ws_sig.set(Some(ws));
        joined.set(true);
        status.set(format!("Joined room \u{201c}{room}\u{201d}"));
    };

    // ---- User-driven video events -> send control messages ----
    let guarded_send = move |make: &dyn Fn(f64) -> ClientMsg| {
        if now_ms() < suppress_until.get_untracked() {
            return;
        }
        if let (Some(ws), Some(el)) = (ws_sig.get_untracked(), video_ref.get_untracked()) {
            send(&ws, &make(el.current_time()));
        }
    };
    let on_play = move |_| guarded_send(&|at| ClientMsg::Play { at });
    let on_pause = move |_| guarded_send(&|at| ClientMsg::Pause { at });
    let on_seeked = move |_| guarded_send(&|to| ClientMsg::Seek { to });

    // ---- Upload ----
    let on_change = move |ev: web_sys::Event| {
        let input: HtmlInputElement = ev.target().unwrap().unchecked_into();
        let Some(files) = input.files() else { return };
        let Some(file) = files.get(0) else { return };
        status.set(format!("Uploading {}\u{2026}", file.name()));
        spawn_local(async move {
            match api::upload(file).await {
                Ok(v) => {
                    status.set(format!("Uploaded {}", v.name));
                    if let Ok(list) = api::fetch_videos().await {
                        videos.set(list);
                    }
                }
                Err(e) => status.set(format!("Upload failed: {e}")),
            }
        });
    };

    view! {
        <main class="wrap">
            <h1>"Watch Party"</h1>

            <Show
                when=move || !joined.get()
                fallback=move || view! {
                    <p class="room-bar">
                        {move || format!(
                            "In room \u{201c}{}\u{201d} \u{00b7} {} watching",
                            room_input.get(),
                            peers.get().len().max(1),
                        )}
                    </p>
                }
            >
                <div class="join">
                    <input class="inp" placeholder="room code"
                        prop:value=move || room_input.get()
                        on:input=move |e| room_input.set(event_target_value(&e))/>
                    <input class="inp" placeholder="your name"
                        prop:value=move || name_input.get()
                        on:input=move |e| name_input.set(event_target_value(&e))/>
                    <button on:click=do_join>"Join"</button>
                </div>
            </Show>

            <p class="status">{move || status.get()}</p>

            <Show
                when=move || current.get().is_some()
                fallback=|| view! { <p class="empty">"Pick a video from the library to start."</p> }
            >
                {move || current.get().map(|v| view! {
                    <video
                        node_ref=video_ref
                        class="player"
                        controls=true
                        src=format!("/media/{}.mp4", v.id)
                        on:play=on_play
                        on:pause=on_pause
                        on:seeked=on_seeked
                    ></video>
                })}
            </Show>

            <label class="upload">"Upload MP4: "
                <input type="file" accept="video/mp4" on:change=on_change/>
            </label>

            <h2>"Library"</h2>
            <ul class="library">
                <For each=move || videos.get() key=|v| v.id.clone() let:v>
                    <li>
                        <button on:click={
                            let v = v.clone();
                            move |_| {
                                current.set(Some(v.clone()));
                                if let Some(ws) = ws_sig.get_untracked() {
                                    send(&ws, &ClientMsg::LoadVideo { video_id: v.id.clone() });
                                }
                            }
                        }>
                            {v.name.clone()}
                        </button>
                    </li>
                </For>
            </ul>

            {move || joined.get().then(|| view! {
                <h2>"Watching now"</h2>
                <ul class="peers">
                    <For each=move || peers.get() key=|p| p.id.clone() let:p>
                        <li>{
                            let mine = me.get_untracked().as_deref() == Some(p.id.as_str());
                            if mine { format!("{} (you)", p.name) } else { p.name.clone() }
                        }</li>
                    </For>
                </ul>
            })}
        </main>
    }
}
